function draw() {
    background(0);
    mostraBolinha();
    //movimentaBolinha();
    verificaColisaoBorda();
    mostraRaquete();
    movimentaMinhaRaquete();
}
function setup() {
  createCanvas(600, 400);
}
let xBolinha = 300
let yBolinha = 200
let diametro = 20
let velocidadeXBolinha = 6
let velocidadeYBolinha = 6

function draw() {
  background(51);
  circle(xBolinha,yBolinha,diametro)
  xBolinha += velocidadeXBolinha
  yBolinha += velocidadeYBolinha
  
  if (xBolinha > 600){velocidadeXBolinha *= -1;}
  if (xBolinha < 0){velocidadeXBolinha *= -1;}
  
  if (yBolinha >400){velocidadeYBolinha *= -1;}
  if (yBolinha <0){velocidadeYBolinha *= -1;}
  
  rect(3,150,12,90);

let xRaquete = 3
let yRaquete = 200
let raqueteLargura = 12
let raqueteAltura = 90

 if (keyIsDown(UP_ARROW)){yRaquete += 10;}
 if (keyIsDown(DOWN_ARROW)){yRaquete += 10;}
    
  rect(585,150,12,90);
    
  
}
